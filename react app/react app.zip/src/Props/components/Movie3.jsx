import React from "react";

function Movie3() {
  return (
    <div className="col-md-4">
      <div className="card">
        <div className="card-body">
          <h5>RRR</h5>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Beatae,
            rerum? Possimus voluptatem repellendus fugit ab adipisci labore
            obcaecati doloribus aspernatur a quidem deserunt veniam assumenda
            esse sint autem, dignissimos vel.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Movie3;
