export let movieName = [
  {
    id: 1,
    movieName: "KGF",
    desp: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, at illum dolore culpa nobis, rem perspiciatis distinctio nisi eaque ab accusamus itaque qui illo vero reprehenderit dolor cum sequi? Quasi.",
  },
  {
    id: 2,
    movieName: "Pushpa",
    desp: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, at illum dolore culpa nobis, rem perspiciatis distinctio nisi eaque ab accusamus itaque qui illo vero reprehenderit dolor cum sequi? Quasi.",
  },
  {
    id: 3,
    movieName: "Pushpa 2",
    desp: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, at illum dolore culpa nobis, rem perspiciatis distinctio nisi eaque ab accusamus itaque qui illo vero reprehenderit dolor cum sequi? Quasi.",
  },
  {
    id: 4,
    movieName: "KGF 2",
    desp: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, at illum dolore culpa nobis, rem perspiciatis distinctio nisi eaque ab accusamus itaque qui illo vero reprehenderit dolor cum sequi? Quasi.",
  },
  {
    id: 5,
    movieName: "RRR",
    desp: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, at illum dolore culpa nobis, rem perspiciatis distinctio nisi eaque ab accusamus itaque qui illo vero reprehenderit dolor cum sequi? Quasi.",
  },
];
