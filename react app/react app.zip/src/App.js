import React from "react";
import Main from "./FetchingDataUsingUseEffect/Main";
function App() {
  return <Main />;
}

export default App;
