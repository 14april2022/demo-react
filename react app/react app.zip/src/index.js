import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(<App />);

// import React from "react";
// import ReactDOM from "react-dom/client";

// // updated
// let root = ReactDOM.createRoot(document.getElementById("root"));
// root.render(<h1>Hello I am updated version</h1>);
// // react 17
// // parameter 1 => UI part kya dikhana H
// // parameter 2 => khape dikhana H

// // ReactDOM.render(<h1>Hello World</h1>, document.getElementById("root"));
